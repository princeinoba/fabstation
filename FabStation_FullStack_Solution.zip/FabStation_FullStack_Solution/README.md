# FabStation - Full Stack Developer Task

A standalone Angular 22 application consumes a .NET 10 Web API and builds a reactive form from the supplied JSON. No database or external service is required.

## Prerequisites

- .NET **10 SDK** (not just the runtime). `global.json` accepts installed stable 10.0 SDK feature bands.
- Node.js **24.15+ within v24** recommended; Angular also supports v22.22.3+ within v22 or v26+. npm is included with Node.
- Internet access for the first package restore. No global Angular CLI installation needed.
- Ports **5050** (API) and **4200** (Angular) available.

## Run (two terminals, from the extracted solution directory)

Terminal 1 - API:

```sh
dotnet restore backend/FabStation.Api/FabStation.Api.csproj
dotnet run --project backend/FabStation.Api/FabStation.Api.csproj --launch-profile http
```

API endpoint: http://localhost:5050/api/fields

Terminal 2 - Angular:

```sh
cd frontend
npm ci
npm start
```

Open http://localhost:4200. Angular's development proxy forwards `/api/**` to the API on port 5050, so no permissive CORS policy is needed. Start both projects; there is no local JSON fallback hiding API failures.

## Build and verify

From the solution root:

```sh
dotnet build backend/FabStation.Api/FabStation.Api.csproj --configuration Release
node scripts/verify-api.mjs
cd frontend
npm test
npm run build
```

The API must be running for `verify-api.mjs`; Angular unit tests use Angular's HTTP testing backend and do not require a running API or browser. The API check compares its full response against the source file. Unit tests cover all field types, typed values, safe option parsing, schema errors, loading/error/retry, reset, and additional API-defined fields.

For interactive unit-test watch mode: `npm run ng -- test --watch`.

## Requirement mapping

| Task | Implementation |
| --- | --- |
| Create an Angular application | `frontend/`: standalone components, HttpClient, signals, reactive forms, strict TypeScript/templates |
| Create a .NET 10 Web API | `backend/FabStation.Api/`: ASP.NET Core minimal API, `net10.0` |
| Expose provided JSON | `GET /api/fields`, sourced from `Data/fields.json` and loaded once at startup |
| Fetch and dynamically create DOM elements | `FieldService` validates the API response; `App` creates controls and renders fields with Angular `@for` / `@switch` |
| Single ZIP without packages/build folders | Source, package manifest/lockfile, project files, tests, and this README only |

## Field mapping and input interpretation

| `dataType` | Rendered element | Form value |
| --- | --- | --- |
| `singleLineText` | Text input | String |
| `number` | Number input | Number, or null when blank |
| `singleChoice` | Select | One option string; initially unselected |
| `MultiChoice` | Checkbox group | String array; initially empty |
| `multiLineText` | Textarea | String |

The original JSON is preserved, including `"0"`, `MultiChoice`, and single-quoted arrays encoded inside strings. The client normalizes type names case-insensitively and converts the numeric default to a number. Choice `value` strings describe the available options, not initial selections. Their legacy syntax is parsed using a restricted grammar; valid JSON string arrays are supported too. No `eval`, `Function`, direct DOM injection, or blanket quote replacement is used.

The task does not specify required fields, age limits, persistence, or submission endpoints, so none are invented. **Preview answers** displays a local snapshot; **Reset form** restores the API defaults. Answers are not posted, stored, or persisted across reloads. New fields using the five supported types need only be added to the JSON; restart the API to reload it. Malformed/unsupported schemas show a retryable error rather than a partial form.

Inputs have associated labels; multi-choice controls use a fieldset/legend. The interface includes loading/error states, keyboard focus indicators, and a responsive layout.

## Structure

```text
backend/FabStation.Api/
  Data/fields.json          Original assignment data
  Models/FieldDefinition.cs
  Program.cs               GET /api/fields
frontend/
  src/app/models/          Typed normalization and parser tests
  src/app/services/        HTTP data access
  src/app/app.*            Dynamic form, styling, component tests
  proxy.conf.json          Development API proxy
  package-lock.json        Reproducible npm dependency restore
scripts/verify-api.mjs      Live API contract check
```

## Deployment notes

This submission is designed to run locally with the commands above. The HTTP development profile avoids local certificate setup. For deployment, use HTTPS and route `/api` to the backend on the same origin as the Angular build; the development proxy is not part of the production bundle.

To publish the backend:

```sh
dotnet publish backend/FabStation.Api/FabStation.Api.csproj --configuration Release --output published-api
```

The JSON is copied to build and publish output. The frontend production files are generated under `frontend/dist/frontend/browser/`. Build outputs and dependencies are intentionally excluded from the submitted ZIP.

## Verification performed

- .NET SDK 10.0.403: Release build and publish passed with zero warnings/errors.
- Node.js 24.22.1: npm dependencies restored and Angular production build passed.
- Angular unit tests: **27 passed** across parser/schema and component tests.
- Live HTTP check: API response matches the supplied JSON; unknown API route returns 404.
- Development proxy: Angular receives the source fields from the running .NET API.
- Chromium interaction check: all six fields, typed preview values, multiple selections, reset, API error/retry, and a 375px mobile viewport passed with no page errors.
