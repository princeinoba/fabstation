import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const base = process.argv[2] ?? 'http://localhost:5050';
const source = JSON.parse(await readFile(new URL('../backend/FabStation.Api/Data/fields.json', import.meta.url), 'utf8'));
const response = await fetch(new URL('/api/fields', base));
assert.equal(response.status, 200, 'GET /api/fields must return 200');
assert.match(response.headers.get('content-type') ?? '', /application\/json/);
assert.deepEqual(await response.json(), source, 'API must return the supplied JSON contract unchanged');
const missing = await fetch(new URL('/api/does-not-exist', base));
assert.equal(missing.status, 404);
console.log('PASS: API returns the original six field definitions as JSON; unknown route returns 404.');
