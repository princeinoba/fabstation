import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { FormField, normalizeFields } from '../models/field';

@Injectable({ providedIn: 'root' })
export class FieldService {
  private readonly http = inject(HttpClient);

  getFields(): Observable<FormField[]> {
    return this.http.get<unknown>('/api/fields').pipe(map(normalizeFields));
  }
}
