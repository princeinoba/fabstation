import { ChangeDetectionStrategy, Component, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { JsonPipe } from '@angular/common';
import { FormControl, FormRecord, ReactiveFormsModule } from '@angular/forms';
import { FieldService } from './services/field.service';
import { FieldValue, FormField } from './models/field';

@Component({
  selector: 'app-root',
  imports: [ReactiveFormsModule, JsonPipe],
  templateUrl: './app.html',
  styleUrl: './app.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App implements OnInit {
  private readonly service = inject(FieldService);
  private readonly destroyRef = inject(DestroyRef);
  readonly fields = signal<FormField[]>([]);
  readonly loading = signal(false);
  readonly error = signal('');
  readonly preview = signal<Record<string, FieldValue> | null>(null);
  form = new FormRecord<FormControl<FieldValue>>({});

  ngOnInit(): void { this.loadFields(); }

  loadFields(): void {
    if (this.loading()) return;
    this.loading.set(true);
    this.error.set('');
    this.preview.set(null);
    this.service.getFields().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: fields => {
        const controls: Record<string, FormControl<FieldValue>> = {};
        for (const field of fields) controls[field.key] = new FormControl<FieldValue>(field.initialValue);
        this.form = new FormRecord(controls);
        this.fields.set(fields);
        this.loading.set(false);
      },
      error: () => {
        this.fields.set([]);
        this.error.set('We could not load the form. Check that the API is running and the field definitions are valid, then try again.');
        this.loading.set(false);
      },
    });
  }

  isSelected(key: string, option: string): boolean {
    const value = this.form.controls[key]?.value;
    return Array.isArray(value) && value.includes(option);
  }

  toggleOption(key: string, option: string, event: Event): void {
    const control = this.form.controls[key];
    const current = control.value;
    if (!Array.isArray(current)) return;
    const checked = (event.target as HTMLInputElement).checked;
    control.setValue(checked ? [...new Set([...current, option])] : current.filter(value => value !== option));
    control.markAsDirty();
  }

  showPreview(): void {
    if (this.form.valid) this.preview.set(this.form.getRawValue());
  }

  resetForm(): void {
    const defaults: Record<string, FieldValue> = {};
    for (const field of this.fields()) defaults[field.key] = field.initialValue;
    this.form.reset(defaults);
    this.preview.set(null);
  }
}
