import { normalizeFields, parseOptions } from './field';

describe('field definitions', () => {
  it('parses the original single-quoted choice lists', () => {
    expect(parseOptions("['male', 'female']")).toEqual(['male', 'female']);
    expect(parseOptions("['Angular', 'CSS', 'Node']")).toEqual(['Angular', 'CSS', 'Node']);
  });

  it('also accepts proper JSON, including apostrophes inside options', () => {
    expect(parseOptions(JSON.stringify(["O'Brien", 'Other']))).toEqual(["O'Brien", 'Other']);
  });

  it.each(['[]', '[1]', "['a', 'a']", "['a']; alert(1)", '[window.location]', "['']"])(
    'rejects invalid or executable option data: %s', value => {
      expect(() => parseOptions(value)).toThrow();
    },
  );

  it('normalizes MultiChoice and treats its value as options, not selected values', () => {
    const [field] = normalizeFields([{ label: 'skills', dataType: 'MultiChoice', value: "['Angular', 'CSS']" }]);
    expect(field.type).toBe('multiChoice');
    expect(field.options).toEqual(['Angular', 'CSS']);
    expect(field.initialValue).toEqual([]);
  });

  it('converts numeric defaults to numbers and keeps text defaults', () => {
    const fields = normalizeFields([
      { label: 'age', dataType: 'number', value: '0' },
      { label: 'firstName', dataType: 'singleLineText', value: 'Prince' },
    ]);
    expect(fields[0].initialValue).toBe(0);
    expect(fields[1].initialValue).toBe('Prince');
    expect(fields[1].label).toBe('First Name');
  });

  it('uses null for a blank numeric default and no default single selection', () => {
    const fields = normalizeFields([
      { label: 'age', dataType: 'number', value: '' },
      { label: 'gender', dataType: 'singleChoice', value: "['male', 'female']" },
    ]);
    expect(fields.map(field => field.initialValue)).toEqual([null, '']);
  });

  it.each([
    null, {}, [], [null],
    [{ label: 'age', dataType: 'number', value: 'not a number' }],
    [{ label: 'field', dataType: 'unknown', value: '' }],
    [{ label: 'field', dataType: '__proto__', value: '' }],
    [{ label: '__proto__', dataType: 'singleLineText', value: '' }],
    [{ label: 'age', dataType: 'number', value: 0 }],
    [{ label: 'x', dataType: 'number', value: '0' }, { label: 'x', dataType: 'number', value: '1' }],
  ])('rejects malformed or unsupported schemas: %j', payload => {
    expect(() => normalizeFields(payload)).toThrow();
  });
});
