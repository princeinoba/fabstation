export type FieldType = 'singleLineText' | 'number' | 'singleChoice' | 'multiChoice' | 'multiLineText';
export type FieldValue = string | number | string[] | null;

export interface FormField {
  key: string;
  label: string;
  type: FieldType;
  options: string[];
  initialValue: FieldValue;
}

const fieldTypes: Record<string, FieldType> = {
  singlelinetext: 'singleLineText',
  number: 'number',
  singlechoice: 'singleChoice',
  multichoice: 'multiChoice',
  multilinetext: 'multiLineText',
};

function checkedOptions(value: unknown): string[] {
  if (!Array.isArray(value) || value.length === 0 ||
      !value.every((option): option is string => typeof option === 'string' && option.trim().length > 0)) {
    throw new Error('Choice options must be a non-empty list of strings.');
  }
  if (new Set(value).size !== value.length) throw new Error('Choice options must be unique.');
  return value;
}

export function parseOptions(value: string): string[] {
  // Accept real JSON arrays first. The assignment instead supplies ['male', 'female'].
  let parsed: unknown;
  try {
    parsed = JSON.parse(value);
  } catch {
    // A deliberately narrow grammar: single-quoted, non-escaped strings only.
    // Never evaluate API data as JavaScript, or globally replace apostrophes.
    if (!/^\[\s*'[^'\\]*'\s*(?:,\s*'[^'\\]*'\s*)*\]$/.test(value.trim())) {
      throw new Error('Invalid choice option list.');
    }
    parsed = Array.from(value.matchAll(/'([^'\\]*)'/g), match => match[1]);
  }
  return checkedOptions(parsed);
}

export function normalizeFields(payload: unknown): FormField[] {
  if (!Array.isArray(payload) || payload.length === 0) throw new Error('Expected a non-empty field array.');
  const keys = new Set<string>();
  return payload.map((item: unknown): FormField => {
    if (item === null || typeof item !== 'object') throw new Error('Invalid field definition.');
    const { label, dataType, value } = item as Record<string, unknown>;
    if (typeof label !== 'string' || !label.trim() || typeof dataType !== 'string' || typeof value !== 'string') {
      throw new Error('Every field requires a label, dataType, and string value.');
    }
    if (keys.has(label) || ['__proto__', 'constructor', 'prototype'].includes(label)) {
      throw new Error('Field labels must be unique and safe control names.');
    }
    keys.add(label);
    const normalizedType = dataType.trim().toLowerCase();
    const type = Object.hasOwn(fieldTypes, normalizedType) ? fieldTypes[normalizedType] : undefined;
    if (!type) throw new Error(`Unsupported field type: ${dataType}`);
    const isChoice = type === 'singleChoice' || type === 'multiChoice';
    let initialValue: FieldValue = value;
    if (type === 'number') {
      initialValue = value.trim() === '' ? null : Number(value);
      if (initialValue !== null && !Number.isFinite(initialValue)) throw new Error('Invalid numeric default.');
    } else if (type === 'singleChoice') initialValue = '';
    else if (type === 'multiChoice') initialValue = [];
    const displayLabel = label.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ');
    return {
      key: label,
      label: displayLabel.charAt(0).toUpperCase() + displayLabel.slice(1),
      type,
      options: isChoice ? parseOptions(value) : [],
      initialValue,
    };
  });
}
