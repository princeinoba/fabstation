import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { App } from './app';

const source = [
  { label: 'firstName', dataType: 'singleLineText', value: '' },
  { label: 'lastName', dataType: 'singleLineText', value: '' },
  { label: 'age', dataType: 'number', value: '0' },
  { label: 'gender', dataType: 'singleChoice', value: "['male', 'female']" },
  { label: 'skills', dataType: 'MultiChoice', value: "['Angular', 'CSS', 'Node']" },
  { label: 'description', dataType: 'multiLineText', value: '' },
];

describe('dynamic form', () => {
  let http: HttpTestingController;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
    http = TestBed.inject(HttpTestingController);
  });
  afterEach(() => http.verify());

  function loadedForm() {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    http.expectOne({ method: 'GET', url: '/api/fields' }).flush(source);
    fixture.detectChanges();
    return fixture;
  }

  it('fetches from the API and renders each supplied field type', () => {
    const fixture = loadedForm();
    const element = fixture.nativeElement as HTMLElement;
    expect(element.querySelectorAll('input[type=text]')).toHaveLength(2);
    expect(element.querySelectorAll('input[type=number]')).toHaveLength(1);
    expect(element.querySelectorAll('select option')).toHaveLength(3);
    expect(element.querySelectorAll('input[type=checkbox]')).toHaveLength(3);
    expect(element.querySelectorAll('textarea')).toHaveLength(1);
    expect((element.querySelector('input[type=number]') as HTMLInputElement).value).toBe('0');
  });

  it('preserves numeric types and multiple selections in the local preview', () => {
    const fixture = loadedForm();
    const element = fixture.nativeElement as HTMLElement;
    const name = element.querySelector('input[type=text]') as HTMLInputElement;
    name.value = 'Prince'; name.dispatchEvent(new Event('input'));
    const age = element.querySelector('input[type=number]') as HTMLInputElement;
    age.value = '32'; age.dispatchEvent(new Event('input'));
    const gender = element.querySelector('select') as HTMLSelectElement;
    gender.value = 'male'; gender.dispatchEvent(new Event('change'));
    const checkboxes = element.querySelectorAll<HTMLInputElement>('input[type=checkbox]');
    checkboxes[0].click(); checkboxes[1].click(); checkboxes[0].click();
    element.querySelector('form')!.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    fixture.detectChanges();
    expect(fixture.componentInstance.preview()).toEqual({
      firstName: 'Prince', lastName: '', age: 32, gender: 'male', skills: ['CSS'], description: '',
    });
    expect(element.querySelector('pre')?.textContent).toContain('Prince');
  });

  it('resets the original defaults and clears the preview', () => {
    const fixture = loadedForm();
    const app = fixture.componentInstance;
    app.form.controls['age'].setValue(42);
    app.form.controls['skills'].setValue(['Angular']);
    app.showPreview(); app.resetForm(); fixture.detectChanges();
    expect(app.form.getRawValue()).toEqual({ firstName: '', lastName: '', age: 0, gender: '', skills: [], description: '' });
    expect(app.preview()).toBeNull();
    expect(app.form.pristine).toBe(true);
  });

  it('shows loading and an actionable API error, then supports retry', () => {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Loading field definitions');
    http.expectOne('/api/fields').flush('Unavailable', { status: 503, statusText: 'Unavailable' });
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role=alert]')).toBeTruthy();
    (fixture.nativeElement.querySelector('button') as HTMLButtonElement).click();
    http.expectOne('/api/fields').flush(source);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('form')).toBeTruthy();
  });

  it('rejects an unsupported schema instead of rendering a partial form', () => {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    http.expectOne('/api/fields').flush([{ label: 'bad', dataType: 'script', value: '' }]);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role=alert]')).toBeTruthy();
    expect(fixture.nativeElement.querySelector('form')).toBeNull();
  });

  it('renders new API fields without hardcoding their labels', () => {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    http.expectOne('/api/fields').flush([...source, { label: 'department', dataType: 'singleLineText', value: 'Engineering' }]);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('input[type=text]')).toHaveLength(3);
    expect(fixture.componentInstance.form.controls['department'].value).toBe('Engineering');
  });
});
