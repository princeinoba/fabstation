See ../README.md for full-stack setup, build, tests, and implementation notes.
