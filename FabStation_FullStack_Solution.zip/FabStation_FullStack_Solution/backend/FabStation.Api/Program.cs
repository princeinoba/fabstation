using System.Text.Json;
using FabStation.Api.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddProblemDetails();
var app = builder.Build();
app.UseExceptionHandler();

// Load and validate once at startup. A missing/invalid source file fails fast.
// AppContext.BaseDirectory also works after dotnet publish and from other directories.
var path = Path.Combine(AppContext.BaseDirectory, "Data", "fields.json");
var fields = JsonSerializer.Deserialize<FieldDefinition[]>(
    File.ReadAllText(path), new JsonSerializerOptions(JsonSerializerDefaults.Web))
    ?? throw new InvalidDataException("The field definition file must contain an array.");
if (fields.Length == 0 || fields.Any(field => field is null ||
    string.IsNullOrWhiteSpace(field.Label) || string.IsNullOrWhiteSpace(field.DataType) || field.Value is null))
{
    throw new InvalidDataException("Each field must have a label, dataType, and string value.");
}

app.MapGet("/api/fields", () => TypedResults.Ok(fields))
    .WithName("GetFields");
app.Run();
