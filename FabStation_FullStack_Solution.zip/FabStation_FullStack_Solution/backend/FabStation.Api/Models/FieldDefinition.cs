namespace FabStation.Api.Models;

// Keep the source contract unchanged, including string-encoded option lists.
public sealed record FieldDefinition(string Label, string DataType, string Value);
